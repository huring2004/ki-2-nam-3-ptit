# import thư viện
import pickle
from flask import Flask, request, json, jsonify
import numpy as np

# tạo một ứng dụng Flask
app = Flask(__name__)

# tên file
filename = 'diabetes.sav'

# tải mô hình đã lưu
loaded_model = pickle.load(open(filename, 'rb'))

# tạo một route để nhận dữ liệu từ client và trả về kết quả dự đoán
@app.route('/diabetes/v1/predict', methods=['POST'])

# hàm dự đoán
def predict():
    # lấy dữ liệu từ client
    features = request.json
    # tạo thành danh sách đặc điểm
    features_list = [features["Glucose"], features["BMI"], features["Age"]]
    features_list = np.array(features_list)
    # đưa ra dự đoán
    prediction = loaded_model.predict([features_list])
    # đưa ra xác suất dự đoán chính xác
    confidence = loaded_model.predict_proba([features_list])
    # trả về kết quả dự đoán và xác suất cho client
    response = {}
    response['prediction'] = int(prediction[0])
    response['confidence'] = str(round(np.amax(confidence[0]) * 100 ,2))
    return jsonify(response)

# chạy ứng dụng
if __name__ == '__main__':
    # chạy ứng dụng trên cổng 5000
    app.run(host='0.0.0.0', port=5000)